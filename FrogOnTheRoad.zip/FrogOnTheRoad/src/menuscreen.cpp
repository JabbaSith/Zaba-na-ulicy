/**
 * @file menuscreen.cpp
 */

#include "menuscreen.h"
#include "ui_menuscreen.h"
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>

MenuScreen::MenuScreen(AudioManager *audio, QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MenuScreen)
    , m_audio(audio)
{
    ui->setupUi(this);   // ← buduje cały UI z pliku .ui

    // Połączenia – objectName z Designer musi być btnPlayer / btnAI
    connect(ui->btnPlayer, &QPushButton::clicked,
            this,          &MenuScreen::onPlayerModeClicked);
    connect(ui->btnAI,     &QPushButton::clicked,
            this,          &MenuScreen::onAIModeClicked);

    if (m_audio) m_audio->playMenuMusic();
}

MenuScreen::~MenuScreen() { delete ui; }


void MenuScreen::onPlayerModeClicked() { emit modeSelected(GameMode::PlayerControlled); }
void MenuScreen::onAIModeClicked()     { emit modeSelected(GameMode::AITraining); }
