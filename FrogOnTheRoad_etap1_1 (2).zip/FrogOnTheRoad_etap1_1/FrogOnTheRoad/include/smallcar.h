#pragma once

/**
 * @file smallcar.h
 * @brief Mały, szybki samochód.
 */

#include "car.h"

/**
 * @class SmallCar
 * @brief Szybki pojazd z małym hitboxem (50x28 px).
 */
class SmallCar : public Car {
    Q_OBJECT
public:
    explicit SmallCar(int laneIndex, float startX = 0.0f, QObject *parent = nullptr);

    void    move()               override;
    QRect   getBoundingRect()    const override;
    QString getType()            const override;
};
