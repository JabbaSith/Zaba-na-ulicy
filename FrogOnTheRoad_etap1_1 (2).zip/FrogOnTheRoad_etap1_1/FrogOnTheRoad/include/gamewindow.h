#pragma once

/**
 * @file gamewindow.h
 * @brief Główne okno aplikacji – przełącza między menu a grą.
 */

#include <QMainWindow>
#include <QStackedWidget>
#include <QLabel>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <memory>
#include "gamedefs.h"
#include "game.h"
#include "menuscreen.h"
#include "audiomanager.h"
#include "skinmanager.h"
#include "aicontroller.h"

/**
 * @class GameWindow
 * @brief MainWindow aplikacji.
 *
 * Zawiera QStackedWidget z MenuScreen (indeks 0) i widokiem gry (indeks 1).
 * Przechwytuje klawisze i przekazuje je do Game lub AIController.
 */
class GameWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit GameWindow(QWidget *parent = nullptr);
    ~GameWindow() override;

    void showMenu();
    void showGame();

protected:
    void keyPressEvent(QKeyEvent *event) override;

private slots:
    void onModeSelected(GameMode mode);
    void onGameOver();
    void onScoreUpdated(int score);

private:
    void setupGameView();

    // Widgety
    QStackedWidget  *m_stack;
    MenuScreen      *m_menu;
    QGraphicsView   *m_gameView;
    QGraphicsScene  *m_scene;
    QLabel          *m_scoreLabel;

    // Logika
    std::unique_ptr<Game>          m_game;
    std::unique_ptr<AIController>  m_aiController;
    std::unique_ptr<AudioManager>  m_audio;
    std::unique_ptr<SkinManager>   m_skinManager;

    GameMode m_gameMode;
};
