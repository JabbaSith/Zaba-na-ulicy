#pragma once

/**
 * @file menuscreen.h
 * @brief Ekran głównego menu.
 */

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include "gamedefs.h"
#include "audiomanager.h"

class GameWindow; // forward declaration

/**
 * @class MenuScreen
 * @brief Widget menu z przyciskami wyboru trybu i skórki.
 *
 * Emituje sygnały do GameWindow z wybranym trybem gry.
 */
class MenuScreen : public QWidget {
    Q_OBJECT
public:
    explicit MenuScreen(AudioManager *audio, QWidget *parent = nullptr);

signals:
    void modeSelected(GameMode mode); ///< Gracz wybrał tryb gry

private slots:
    void onPlayerModeClicked();
    void onAIModeClicked();

private:
    void setupUI();

    QPushButton *m_btnPlayer;
    QPushButton *m_btnAI;
    QLabel      *m_title;
    AudioManager *m_audio;
};
