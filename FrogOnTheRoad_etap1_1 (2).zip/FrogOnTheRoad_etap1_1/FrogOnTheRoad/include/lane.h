#pragma once

/**
 * @file lane.h
 * @brief Pas ruchu – generuje i zarządza samochodami.
 */

#include <QObject>
#include <QGraphicsScene>
#include <vector>
#include <memory>
#include "car.h"

/**
 * @class Lane
 * @brief Jeden pas ruchu na planszy.
 *
 * Co m_spawnInterval tików spawnuje losowy pojazd.
 * Parzyste pasy – ruch w prawo; nieparzyste – w lewo (ujemna prędkość).
 */
class Lane : public QObject {
    Q_OBJECT
public:
    explicit Lane(int laneIndex, QObject *parent = nullptr);

    /** @brief Aktualizuje pojazdy (move) i odlicza do spawnu. */
    void update();

    /** @brief Tworzy nowy losowy pojazd na tym pasie. */
    void spawnCar();

    /** @brief Rysuje wszystkie pojazdy na scenie. */
    void draw(QGraphicsScene *scene) const;

    /** @brief Czyści wszystkie pojazdy (np. po resecie). */
    void clear();

    /** @brief Dostęp do pojazdów (do kolizji). */
    const std::vector<std::unique_ptr<Car>>& getCars() const;

private:
    int  m_laneIndex;
    int  m_spawnTimer;
    int  m_spawnInterval;
    std::vector<std::unique_ptr<Car>> m_cars;
};
