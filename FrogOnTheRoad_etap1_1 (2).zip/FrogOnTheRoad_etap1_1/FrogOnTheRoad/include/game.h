#pragma once

/**
 * @file game.h
 * @brief Klasa Game – główna logika rozgrywki.
 */

#include <QObject>
#include <QTimer>
#include <QGraphicsScene>
#include <vector>
#include <memory>
#include "gamedefs.h"
#include "player.h"
#include "lane.h"
#include "collisiondetector.h"
#include "scoremanager.h"
#include "audiomanager.h"
#include "skinmanager.h"

/**
 * @class Game
 * @brief Orkiestruje pętlę gry: timer → update → render.
 *
 * Tworzy Player, Lanes, CollisionDetector i ScoreManager.
 * Na każdy tik timera (GAME_TICK_MS) woła tick().
 */
class Game : public QObject {
    Q_OBJECT
public:
    /**
     * @brief Konstruktor.
     * @param scene       Scena Qt Graphics do renderowania.
     * @param skinManager Menedżer skórek (właściciel skórek).
     * @param parent      Rodzic Qt.
     */
    explicit Game(QGraphicsScene *scene, SkinManager *skinManager,
                  QObject *parent = nullptr);

    void startGame();
    void pauseGame();
    void endGame();

    /** @brief Wywołane przez GameWindow po keyPressEvent. */
    void handleInput(Direction dir);

    Player*       getPlayer()  const;
    ScoreManager* getScore()   const;

    bool isRunning() const;

signals:
    void gameOver();        ///< Emitowany po śmierci żaby
    void scoreUpdated(int); ///< Przekazuje nowy wynik do UI

private slots:
    /** @brief Jeden krok symulacji (wywoływany przez QTimer). */
    void tick();

private:
    void resetGame();
    void renderFrame();

    QGraphicsScene               *m_scene;
    QTimer                        m_timer;
    std::unique_ptr<Player>       m_player;
    std::vector<std::unique_ptr<Lane>> m_lanes;
    std::unique_ptr<CollisionDetector> m_collision;
    std::unique_ptr<ScoreManager>      m_score;
    SkinManager                       *m_skinManager;
    bool  m_running;
    int   m_tick;
};
