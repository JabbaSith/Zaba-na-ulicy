#pragma once

/**
 * @file gamedefs.h
 * @brief Wspólne stałe, enumeracje i typy używane w całym projekcie.
 */

// ── Rozmiary sceny ────────────────────────────────────────────────────────────
constexpr int SCENE_WIDTH  = 800;
constexpr int SCENE_HEIGHT = 600;

// ── Gracz ─────────────────────────────────────────────────────────────────────
constexpr int PLAYER_SIZE = 40;
constexpr int PLAYER_STEP = 40;

// ── Pasy ruchu ────────────────────────────────────────────────────────────────
constexpr int LANE_COUNT    = 5;
constexpr int LANE_HEIGHT   = 80;
constexpr int LANE_Y_START  = 100;

// ── Prędkości samochodów ──────────────────────────────────────────────────────
constexpr float SPEED_SMALL = 4.0f;
constexpr float SPEED_TRUCK = 2.0f;
constexpr float SPEED_SUV   = 3.0f;

// ── Timer gry ─────────────────────────────────────────────────────────────────
constexpr int GAME_TICK_MS = 30;

/**
 * @brief Tryby gry dostępne z menu.
 */
enum class GameMode {
    PlayerControlled, ///< Gracz steruje klawiszami
    AITraining        ///< Tryb treningu AI
};

/**
 * @brief Kierunki ruchu gracza.
 */
enum class Direction {
    Up,
    Down,
    Left,
    Right,
    None
};
