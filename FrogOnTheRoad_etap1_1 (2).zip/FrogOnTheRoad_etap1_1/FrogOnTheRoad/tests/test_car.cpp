/**
 * @file test_car.cpp
 * @brief Testy jednostkowe klas pojazdów.
 */

#include <gtest/gtest.h>
#include "smallcar.h"
#include "truck.h"
#include "suv.h"
#include "gamedefs.h"

TEST(SmallCarTest, TypeString) {
    SmallCar c(0);
    EXPECT_EQ(c.getType(), "SmallCar");
}

TEST(SmallCarTest, BoundingRectNonEmpty) {
    SmallCar c(0);
    QRect r = c.getBoundingRect();
    EXPECT_GT(r.width(),  0);
    EXPECT_GT(r.height(), 0);
}

TEST(SmallCarTest, MovesForward) {
    SmallCar c(0, 100.0f);
    float before = c.getX();
    c.move();
    EXPECT_FLOAT_EQ(c.getX(), before + SPEED_SMALL);
}

TEST(TruckTest, TypeString) {
    Truck t(1);
    EXPECT_EQ(t.getType(), "Truck");
}

TEST(TruckTest, SlowerThanSmallCar) {
    SmallCar sc(0, 0.0f);
    Truck    tr(0, 0.0f);
    float xSC = sc.getX(); sc.move();
    float xTr = tr.getX(); tr.move();
    EXPECT_LT(tr.getX() - xTr, sc.getX() - xSC);
}

TEST(SUVTest, TypeString) {
    SUV s(2);
    EXPECT_EQ(s.getType(), "SUV");
}

TEST(SUVTest, LaneIndexStored) {
    SUV s(3);
    EXPECT_EQ(s.getLaneIndex(), 3);
}
