/**
 * @file test_lane.cpp
 * @brief Testy klasy Lane.
 */

#include <gtest/gtest.h>
#include "lane.h"

TEST(LaneTest, InitiallyEmpty) {
    Lane lane(0);
    EXPECT_TRUE(lane.getCars().empty());
}

TEST(LaneTest, SpawnCarAddsOne) {
    Lane lane(0);
    lane.spawnCar();
    EXPECT_EQ(lane.getCars().size(), 1u);
}

TEST(LaneTest, ClearRemovesAll) {
    Lane lane(0);
    lane.spawnCar();
    lane.spawnCar();
    lane.clear();
    EXPECT_TRUE(lane.getCars().empty());
}

TEST(LaneTest, UpdateSpawnsEventually) {
    Lane lane(0);
    // Wywołaj update 200 razy – spawn interval to maks 60+4*15=120 tików
    for (int i = 0; i < 200; ++i)
        lane.update();
    EXPECT_GT(lane.getCars().size(), 0u);
}
