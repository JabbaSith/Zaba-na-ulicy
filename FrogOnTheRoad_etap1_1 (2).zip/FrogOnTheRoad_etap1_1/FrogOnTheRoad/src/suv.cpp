/**
 * @file suv.cpp
 */

#include "suv.h"
#include "gamedefs.h"

SUV::SUV(int laneIndex, float startX, QObject *parent)
    : Car(startX,
          LANE_Y_START + laneIndex * LANE_HEIGHT + (LANE_HEIGHT - 35) / 2,
          SPEED_SUV, laneIndex, 70, 35, parent)
{}

void SUV::move() {
    m_x += m_speed;
    if (m_x > SCENE_WIDTH)       m_x = (float)-m_width;
    if (m_x + m_width < 0)       m_x = (float)SCENE_WIDTH;
}

QRect   SUV::getBoundingRect() const { return {(int)m_x, (int)m_y, m_width, m_height}; }
QString SUV::getType()         const { return "SUV"; }
