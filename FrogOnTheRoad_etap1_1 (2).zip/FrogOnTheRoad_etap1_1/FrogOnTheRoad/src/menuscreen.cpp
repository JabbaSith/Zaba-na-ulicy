/**
 * @file menuscreen.cpp
 */

#include "menuscreen.h"
#include <QVBoxLayout>
#include <QHBoxLayout>

MenuScreen::MenuScreen(AudioManager *audio, QWidget *parent)
    : QWidget(parent), m_audio(audio)
{
    setupUI();
    if (m_audio) m_audio->playMenuMusic();
}

void MenuScreen::setupUI() {
    auto *layout = new QVBoxLayout(this);
    layout->setAlignment(Qt::AlignCenter);
    layout->setSpacing(20);

    m_title = new QLabel("🐸  Frog on the Road", this);
    m_title->setAlignment(Qt::AlignCenter);
    m_title->setStyleSheet("font-size: 32px; font-weight: bold; color: #4caf50;");

    m_btnPlayer = new QPushButton("▶  Sterowanie gracza", this);
    m_btnPlayer->setFixedSize(260, 55);
    m_btnPlayer->setStyleSheet(
        "QPushButton { background:#4caf50; color:white; border-radius:8px; font-size:16px; }"
        "QPushButton:hover { background:#388e3c; }");

    m_btnAI = new QPushButton("🤖  Trening AI", this);
    m_btnAI->setFixedSize(260, 55);
    m_btnAI->setStyleSheet(
        "QPushButton { background:#1565c0; color:white; border-radius:8px; font-size:16px; }"
        "QPushButton:hover { background:#0d47a1; }");

    layout->addStretch();
    layout->addWidget(m_title);
    layout->addSpacing(30);
    layout->addWidget(m_btnPlayer, 0, Qt::AlignCenter);
    layout->addWidget(m_btnAI,     0, Qt::AlignCenter);
    layout->addStretch();

    connect(m_btnPlayer, &QPushButton::clicked, this, &MenuScreen::onPlayerModeClicked);
    connect(m_btnAI,     &QPushButton::clicked, this, &MenuScreen::onAIModeClicked);
}

void MenuScreen::onPlayerModeClicked() { emit modeSelected(GameMode::PlayerControlled); }
void MenuScreen::onAIModeClicked()     { emit modeSelected(GameMode::AITraining); }
