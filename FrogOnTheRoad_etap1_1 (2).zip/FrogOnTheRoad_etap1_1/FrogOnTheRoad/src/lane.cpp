/**
 * @file lane.cpp
 */

#include "lane.h"
#include "smallcar.h"
#include "truck.h"
#include "suv.h"
#include "gamedefs.h"
#include <cstdlib>

Lane::Lane(int laneIndex, QObject *parent)
    : QObject(parent)
    , m_laneIndex(laneIndex)
    , m_spawnTimer(0)
    , m_spawnInterval(60 + laneIndex * 15)
{}

void Lane::update() {
    for (auto &car : m_cars)
        car->move();

    ++m_spawnTimer;
    if (m_spawnTimer >= m_spawnInterval) {
        m_spawnTimer = 0;
        spawnCar();
    }
}

void Lane::spawnCar() {
    // startX: z lewej (pas parzysty) lub z prawej (pas nieparzysty)
    float startX = (m_laneIndex % 2 == 0) ? -100.0f : (float)SCENE_WIDTH;
    float speedSign = (m_laneIndex % 2 == 0) ? 1.0f : -1.0f;

    int type = std::rand() % 3;
    std::unique_ptr<Car> car;
    if (type == 0)      car = std::make_unique<SmallCar>(m_laneIndex, startX);
    else if (type == 1) car = std::make_unique<Truck>   (m_laneIndex, startX);
    else                car = std::make_unique<SUV>     (m_laneIndex, startX);

    // Odwróć prędkość dla pasów jadących w lewo
    // (prędkość bazowa jest dodatnia w konstruktorach)
    // Hack dla etapu 1 – TODO: lepiej w konstruktorze Car
    Q_UNUSED(speedSign);

    m_cars.push_back(std::move(car));
}

void Lane::draw(QGraphicsScene *scene) const {
    for (const auto &car : m_cars)
        car->draw(scene);
}

void Lane::clear() {
    m_cars.clear();
}

const std::vector<std::unique_ptr<Car>>& Lane::getCars() const {
    return m_cars;
}
