/**
 * @file truck.cpp
 */

#include "truck.h"
#include "gamedefs.h"

Truck::Truck(int laneIndex, float startX, QObject *parent)
    : Car(startX,
          LANE_Y_START + laneIndex * LANE_HEIGHT + (LANE_HEIGHT - 40) / 2,
          SPEED_TRUCK, laneIndex, 90, 40, parent)
{}

void Truck::move() {
    m_x += m_speed;
    if (m_x > SCENE_WIDTH)       m_x = (float)-m_width;
    if (m_x + m_width < 0)       m_x = (float)SCENE_WIDTH;
}

QRect   Truck::getBoundingRect() const { return {(int)m_x, (int)m_y, m_width, m_height}; }
QString Truck::getType()         const { return "Truck"; }
