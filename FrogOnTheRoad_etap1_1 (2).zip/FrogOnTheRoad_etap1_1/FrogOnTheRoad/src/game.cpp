/**
 * @file game.cpp
 */

#include "game.h"
#include <QGraphicsTextItem>
#include <QDebug>

Game::Game(QGraphicsScene *scene, SkinManager *skinManager, QObject *parent)
    : QObject(parent)
    , m_scene(scene)
    , m_skinManager(skinManager)
    , m_running(false)
    , m_tick(0)
{
    // Tworzenie gracza na dole sceny
    m_player = std::make_unique<Player>(SCENE_WIDTH / 2 - PLAYER_SIZE / 2,
                                        SCENE_HEIGHT - PLAYER_SIZE - 10, this);
    m_player->setSkin(m_skinManager->getActiveSkin());

    // Tworzenie pasów
    for (int i = 0; i < LANE_COUNT; ++i)
        m_lanes.push_back(std::make_unique<Lane>(i, this));

    m_collision = std::make_unique<CollisionDetector>(this);
    m_score     = std::make_unique<ScoreManager>(this);

    connect(&m_timer, &QTimer::timeout, this, &Game::tick);
    connect(m_score.get(), &ScoreManager::scoreChanged,
            this,          &Game::scoreUpdated);
}

void Game::startGame() {
    resetGame();
    m_running = true;
    m_timer.start(GAME_TICK_MS);
}

void Game::pauseGame() {
    if (m_running) m_timer.stop();
    else           m_timer.start(GAME_TICK_MS);
    m_running = !m_running;
}

void Game::endGame() {
    m_timer.stop();
    m_running = false;
    emit gameOver();
}

void Game::handleInput(Direction dir) {
    if (!m_running) return;
    m_player->move(dir);

    // Gracz dotarł do górnej krawędzi – punkt
    if (m_player->getY() <= 0) {
        m_score->addPoints(100);
        m_player->reset();
    }
}

Player*       Game::getPlayer() const { return m_player.get(); }
ScoreManager* Game::getScore()  const { return m_score.get(); }
bool          Game::isRunning() const { return m_running; }

void Game::tick() {
    ++m_tick;

    // Aktualizuj pasy
    for (auto &lane : m_lanes)
        lane->update();

    // Sprawdź kolizje
    if (m_collision->checkCollision(*m_player, m_lanes)) {
        m_player->setAlive(false);
        endGame();
        return;
    }

    renderFrame();
}

void Game::resetGame() {
    m_tick = 0;
    m_player->reset();
    m_player->setSkin(m_skinManager->getActiveSkin());
    for (auto &lane : m_lanes)
        lane->clear();
    m_score->reset();
}

void Game::renderFrame() {
    m_scene->clear();

    // Tło – zielone (start/meta) + szare pasy
    m_scene->setBackgroundBrush(QColor(34, 139, 34));  // trawa

    // Narysuj pasy jako szare prostokąty
    for (int i = 0; i < LANE_COUNT; ++i) {
        int y = LANE_Y_START + i * LANE_HEIGHT;
        m_scene->addRect(0, y, SCENE_WIDTH, LANE_HEIGHT,
                         Qt::NoPen, QColor(80, 80, 80));
        // Przerywana linia środkowa
        for (int x = 0; x < SCENE_WIDTH; x += 60) {
            m_scene->addRect(x, y + LANE_HEIGHT / 2 - 2, 40, 4,
                             Qt::NoPen, QColor(220, 220, 0));
        }
    }

    // Rysuj pojazdy
    for (auto &lane : m_lanes)
        lane->draw(m_scene);

    // Rysuj gracza
    m_player->draw(m_scene, m_tick);
}
