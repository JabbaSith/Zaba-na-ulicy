/**
 * @file gamewindow.cpp
 */

#include "gamewindow.h"
#include <QKeyEvent>
#include <QVBoxLayout>
#include <QWidget>
#include <QTimer>
#include <QDebug>

GameWindow::GameWindow(QWidget *parent)
    : QMainWindow(parent)
    , m_gameMode(GameMode::PlayerControlled)
{
    setWindowTitle("Frog on the Road");
    setFixedSize(SCENE_WIDTH, SCENE_HEIGHT + 40); // +40 na pasek wyników

    // Menedżery
    m_audio       = std::make_unique<AudioManager>(this);
    m_skinManager = std::make_unique<SkinManager>(this);

    // Centralny widget
    auto *central = new QWidget(this);
    auto *vbox    = new QVBoxLayout(central);
    vbox->setContentsMargins(0, 0, 0, 0);
    vbox->setSpacing(0);
    setCentralWidget(central);

    // Pasek wyników (góra)
    m_scoreLabel = new QLabel("Wynik: 0  |  Rekord: 0", this);
    m_scoreLabel->setAlignment(Qt::AlignCenter);
    m_scoreLabel->setFixedHeight(30);
    m_scoreLabel->setStyleSheet("background:#222; color:#4caf50; font-size:14px; font-weight:bold;");
    vbox->addWidget(m_scoreLabel);

    // Stack
    m_stack = new QStackedWidget(this);
    vbox->addWidget(m_stack);

    // Menu
    m_menu = new MenuScreen(m_audio.get(), this);
    m_stack->addWidget(m_menu);   // index 0

    // Widok gry
    setupGameView();               // index 1

    connect(m_menu, &MenuScreen::modeSelected, this, &GameWindow::onModeSelected);

    showMenu();
}

GameWindow::~GameWindow() = default;

void GameWindow::setupGameView() {
    m_scene = new QGraphicsScene(0, 0, SCENE_WIDTH, SCENE_HEIGHT, this);
    m_gameView = new QGraphicsView(m_scene, this);
    m_gameView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_gameView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_gameView->setFixedSize(SCENE_WIDTH, SCENE_HEIGHT);
    m_stack->addWidget(m_gameView); // index 1
}

void GameWindow::showMenu() {
    m_stack->setCurrentIndex(0);
    m_audio->playMenuMusic();
}

void GameWindow::showGame() {
    // Twórz nową grę z aktualnym SkinManager
    m_game = std::make_unique<Game>(m_scene, m_skinManager.get(), this);
    connect(m_game.get(), &Game::gameOver,      this, &GameWindow::onGameOver);
    connect(m_game.get(), &Game::scoreUpdated,  this, &GameWindow::onScoreUpdated);

    // Tryb AI
    if (m_gameMode == GameMode::AITraining) {
        m_aiController = std::make_unique<AIController>(this);
        qDebug() << "[GameWindow] AI Training mode – AI będzie sterować żabą";
        // TODO (Etap 2): podłączyć AIController do pętli gry
    } else {
        m_aiController.reset();
    }

    m_stack->setCurrentIndex(1);
    m_audio->playGameMusic();
    m_game->startGame();
}

void GameWindow::keyPressEvent(QKeyEvent *event) {
    if (!m_game || !m_game->isRunning()) return;

    Direction dir = Direction::None;
    switch (event->key()) {
        case Qt::Key_Up:    dir = Direction::Up;    break;
        case Qt::Key_Down:  dir = Direction::Down;  break;
        case Qt::Key_Left:  dir = Direction::Left;  break;
        case Qt::Key_Right: dir = Direction::Right; break;
        case Qt::Key_Escape:
            m_game->endGame();
            showMenu();
            return;
        default: break;
    }

    if (dir != Direction::None && m_gameMode == GameMode::PlayerControlled)
        m_game->handleInput(dir);
}

void GameWindow::onModeSelected(GameMode mode) {
    m_gameMode = mode;
    showGame();
}

void GameWindow::onGameOver() {
    m_scoreLabel->setText(
        QString("KONIEC GRY!  Wynik: %1  |  Rekord: %2")
            .arg(m_game->getScore()->getCurrentScore())
            .arg(m_game->getScore()->getHighScore()));
    // Po 2 sek wróć do menu – TODO (Etap 2): ekran Game Over
    QTimer::singleShot(2000, this, &GameWindow::showMenu);
}

void GameWindow::onScoreUpdated(int score) {
    m_scoreLabel->setText(
        QString("Wynik: %1  |  Rekord: %2")
            .arg(score)
            .arg(m_game ? m_game->getScore()->getHighScore() : 0));
    // Odblokuj skórki
    if (m_skinManager)
        m_skinManager->tryUnlock(score);
}
